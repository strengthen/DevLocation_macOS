#!/usr/bin/env python3
"""
AFC (Apple File Connection) Service Module

This module provides an interface to interact with iOS devices' file systems through the AFC protocol.
It supports file operations like reading, writing, deleting, and directory traversal, as well as an
interactive shell for navigating the device's file system rooted at /var/mobile/Media.
"""

import asyncio
import contextlib
import inspect
import logging
import os
import pathlib
import posixpath
import shlex
import shutil
import stat as stat_module
import struct
import sys
import threading
import warnings
from collections.abc import AsyncIterator, Iterator, MutableMapping, MutableSequence
from dataclasses import dataclass, field
from datetime import datetime
from re import Pattern
from types import TracebackType
from typing import Any, Callable, NamedTuple, Optional, TextIO, TypeVar, Union, cast

import hexdump
import parameter_decorators
import xonsh.cli_utils
import xonsh.main
import xonsh.tools
from construct import Bytes, CString, GreedyRange, Int64sl, Int64ul, Tell
from construct_typed import DataclassMixin, EnumBase, TEnum, TStruct, csfield
from pygments import formatters, highlight, lexers

# `ls_cli` is a real-click command; the click it raises exceptions from is pygnuutils' own
# dependency, so resolve it through pygnuutils instead of importing click directly.
from pygnuutils.cli.ls import click as _ls_cli_click
from pygnuutils.cli.ls import ls as ls_cli
from pygnuutils.ls import Ls, LsStub
from tqdm.auto import tqdm
from xonsh.built_ins import XSH
from xonsh.cli_utils import Annotated, ArgParserAlias

from pymobiledevice3.construct_compat import const_field
from pymobiledevice3.exceptions import AfcException, AfcFileNotFoundError, ArgumentError, ConnectionTerminatedError
from pymobiledevice3.lockdown import LockdownClient
from pymobiledevice3.lockdown_service_provider import LockdownServiceProvider
from pymobiledevice3.services.lockdown_service import LockdownService
from pymobiledevice3.utils import get_asyncio_loop, try_decode

# These symbols come from untyped third-party modules; re-bind them with explicit types so their
# uses type-check without leaking Unknown into this module.
_F = TypeVar("_F", bound=Callable[..., Any])


def path_to_str(*args: Any, **kwargs: Any) -> Callable[[_F], _F]:
    """Signature-preserving wrapper over the untyped ``parameter_decorators.path_to_str``."""
    return cast(Callable[[_F], _F], cast(Any, parameter_decorators).path_to_str(*args, **kwargs))


Arg = cast(Callable[..., Any], cast(Any, xonsh.cli_utils).Arg)
xonsh_main = cast(Callable[..., Any], cast(Any, xonsh.main).main)
print_color = cast(Callable[..., Any], cast(Any, xonsh.tools).print_color)


def _xsh_ctx() -> dict[str, Any]:
    """Typed accessor for the untyped ``XSH.ctx`` mapping."""
    return cast(dict[str, Any], cast(Any, XSH).ctx)


MAXIMUM_READ_SIZE = 4 * 1024**2  # 4 MB
MODE_MASK = 0o0000777


class StatResult(NamedTuple):
    st_mode: int
    st_ino: int
    st_dev: int
    st_nlink: int
    st_uid: int
    st_gid: int
    st_size: int
    st_atime: float
    st_mtime: float
    st_ctime: float
    st_blocks: int
    st_blksize: int
    st_birthtime: float


class AfcOpcode(EnumBase):
    STATUS = 0x00000001
    DATA = 0x00000002  # Data
    READ_DIR = 0x00000003  # ReadDir
    READ_FILE = 0x00000004  # ReadFile
    WRITE_FILE = 0x00000005  # WriteFile
    WRITE_PART = 0x00000006  # WritePart
    TRUNCATE = 0x00000007  # TruncateFile
    REMOVE_PATH = 0x00000008  # RemovePath
    MAKE_DIR = 0x00000009  # MakeDir
    GET_FILE_INFO = 0x0000000A  # GetFileInfo
    GET_DEVINFO = 0x0000000B  # GetDeviceInfo
    WRITE_FILE_ATOM = 0x0000000C  # WriteFileAtomic (tmp file+rename)
    FILE_OPEN = 0x0000000D  # FileRefOpen
    FILE_OPEN_RES = 0x0000000E  # FileRefOpenResult
    READ = 0x0000000F  # FileRefRead
    WRITE = 0x00000010  # FileRefWrite
    FILE_SEEK = 0x00000011  # FileRefSeek
    FILE_TELL = 0x00000012  # FileRefTell
    FILE_TELL_RES = 0x00000013  # FileRefTellResult
    FILE_CLOSE = 0x00000014  # FileRefClose
    FILE_SET_SIZE = 0x00000015  # FileRefSetFileSize (ftruncate)
    GET_CON_INFO = 0x00000016  # GetConnectionInfo
    SET_CON_OPTIONS = 0x00000017  # SetConnectionOptions
    RENAME_PATH = 0x00000018  # RenamePath
    SET_FS_BS = 0x00000019  # SetFSBlockSize (0x800000)
    SET_SOCKET_BS = 0x0000001A  # SetSocketBlockSize (0x800000)
    FILE_LOCK = 0x0000001B  # FileRefLock
    MAKE_LINK = 0x0000001C  # MakeLink
    SET_FILE_TIME = 0x0000001E  # set st_mtime


class AfcError(EnumBase):
    SUCCESS = 0
    UNKNOWN_ERROR = 1
    OP_HEADER_INVALID = 2
    NO_RESOURCES = 3
    READ_ERROR = 4
    WRITE_ERROR = 5
    UNKNOWN_PACKET_TYPE = 6
    INVALID_ARG = 7
    OBJECT_NOT_FOUND = 8
    OBJECT_IS_DIR = 9
    PERM_DENIED = 10
    SERVICE_NOT_CONNECTED = 11
    OP_TIMEOUT = 12
    TOO_MUCH_DATA = 13
    END_OF_DATA = 14
    OP_NOT_SUPPORTED = 15
    OBJECT_EXISTS = 16
    OBJECT_BUSY = 17
    NO_SPACE_LEFT = 18
    OP_WOULD_BLOCK = 19
    IO_ERROR = 20
    OP_INTERRUPTED = 21
    OP_IN_PROGRESS = 22
    INTERNAL_ERROR = 23
    MUX_ERROR = 30
    NO_MEM = 31
    NOT_ENOUGH_DATA = 32
    DIR_NOT_EMPTY = 33


class AfcLinkType(EnumBase):
    HARDLINK = 1
    SYMLINK = 2


class AfcFopenMode(EnumBase):
    RDONLY = 0x00000001  # r   O_RDONLY
    RW = 0x00000002  # r+  O_RDWR   | O_CREAT
    WRONLY = 0x00000003  # w   O_WRONLY | O_CREAT  | O_TRUNC
    WR = 0x00000004  # w+  O_RDWR   | O_CREAT  | O_TRUNC
    APPEND = 0x00000005  # a   O_WRONLY | O_APPEND | O_CREAT
    RDAPPEND = 0x00000006  # a+  O_RDWR   | O_APPEND | O_CREAT


# typed construct adapters for the enums
afc_opcode_t = TEnum(Int64ul, AfcOpcode)
afc_error_construct = TEnum(Int64ul, AfcError)
afc_link_type_construct = TEnum(Int64ul, AfcLinkType)
afc_fopen_mode_construct = TEnum(Int64ul, AfcFopenMode)

AFC_FOPEN_TEXTUAL_MODES = {
    "r": AfcFopenMode.RDONLY,
    "r+": AfcFopenMode.RW,
    "w": AfcFopenMode.WRONLY,
    "w+": AfcFopenMode.WR,
    "a": AfcFopenMode.APPEND,
    "a+": AfcFopenMode.RDAPPEND,
}

AFC_LOCK_SH = 1 | 4  # shared lock
AFC_LOCK_EX = 2 | 4  # exclusive lock
AFC_LOCK_UN = 8 | 4  # unlock

MAXIMUM_WRITE_SIZE = 1 << 30

AFCMAGIC = b"CFA6LPAA"


@dataclass
class AfcHeader(DataclassMixin):
    # const_field() makes ``magic`` init=False at runtime, but pyright can't see that through the
    # construct-typing stubs and flags the non-default fields that follow. Field order is the AFC wire
    # format.
    magic: bytes = const_field(Bytes(len(AFCMAGIC)), AFCMAGIC)
    entire_length: int = csfield(Int64ul)  # pyright: ignore[reportGeneralTypeIssues]
    this_length: int = csfield(Int64ul)  # pyright: ignore[reportGeneralTypeIssues]
    packet_num: int = csfield(Int64ul)  # pyright: ignore[reportGeneralTypeIssues]
    operation: AfcOpcode = csfield(afc_opcode_t)  # pyright: ignore[reportGeneralTypeIssues]
    _data_offset: int = field(default=0, init=False, metadata={"subcon": Tell})


@dataclass
class AfcReadDirRequest(DataclassMixin):
    filename: str = csfield(CString("utf8"))


@dataclass
class AfcReadDirResponse(DataclassMixin):
    filenames: list[str] = csfield(GreedyRange(CString("utf8")))


@dataclass
class AfcMkdirRequest(DataclassMixin):
    filename: str = csfield(CString("utf8"))


@dataclass
class AfcStatRequest(DataclassMixin):
    filename: str = csfield(CString("utf8"))


@dataclass
class AfcMakeLinkRequest(DataclassMixin):
    type: AfcLinkType = csfield(afc_link_type_construct)
    target: str = csfield(CString("utf8"))
    source: str = csfield(CString("utf8"))


@dataclass
class AfcFopenRequest(DataclassMixin):
    mode: AfcFopenMode = csfield(afc_fopen_mode_construct)
    filename: str = csfield(CString("utf8"))


@dataclass
class AfcFopenResponse(DataclassMixin):
    handle: int = csfield(Int64ul)


@dataclass
class AfcFcloseRequest(DataclassMixin):
    handle: int = csfield(Int64ul)


@dataclass
class AfcRmRequest(DataclassMixin):
    filename: str = csfield(CString("utf8"))


@dataclass
class AfcRenameRequest(DataclassMixin):
    source: str = csfield(CString("utf8"))
    target: str = csfield(CString("utf8"))


@dataclass
class AfcFreadRequest(DataclassMixin):
    handle: int = csfield(Int64ul)
    size: int = csfield(Int64ul)


@dataclass
class AfcLockRequest(DataclassMixin):
    handle: int = csfield(Int64ul)
    op: int = csfield(Int64ul)


@dataclass
class AfcFileSeekRequest(DataclassMixin):
    handle: int = csfield(Int64ul)
    whence: int = csfield(Int64ul)
    offset: int = csfield(Int64sl)


afc_header_t = TStruct(AfcHeader)
afc_read_dir_req_t = TStruct(AfcReadDirRequest)
afc_read_dir_resp_t = TStruct(AfcReadDirResponse)
afc_mkdir_req_t = TStruct(AfcMkdirRequest)
afc_stat_t = TStruct(AfcStatRequest)
afc_make_link_req_t = TStruct(AfcMakeLinkRequest)
afc_fopen_req_t = TStruct(AfcFopenRequest)
afc_fopen_resp_t = TStruct(AfcFopenResponse)
afc_fclose_req_t = TStruct(AfcFcloseRequest)
afc_rm_req_t = TStruct(AfcRmRequest)
afc_rename_req_t = TStruct(AfcRenameRequest)
afc_fread_req_t = TStruct(AfcFreadRequest)
afc_lock_t = TStruct(AfcLockRequest)
afc_fseek_req_t = TStruct(AfcFileSeekRequest)


def list_to_dict(raw: bytes) -> dict[str, str]:
    """
    Convert a null-terminated key-value list to a dictionary.

    The input is expected to be a byte string with alternating keys and values,
    each separated by null bytes (``\\x00``).
    """
    parts = raw.decode("utf-8").split("\x00")[:-1]
    if len(parts) % 2:
        raise ValueError("AFC list is not key/value aligned")
    return dict(zip(parts[::2], parts[1::2]))


class AfcService(LockdownService):
    """
    Apple File Connection (AFC) Service for iOS device file system access.

    This service provides full file system access to the /var/mobile/Media directory
    on iOS devices. It supports standard file operations including read, write, delete,
    rename, and directory operations.

    The service communicates using a custom binary protocol with operation codes for
    different file system operations. AFC responses echo the ``packet_num`` from the
    request, enabling full concurrent operation: multiple callers may issue operations
    simultaneously and a background reader task routes each response to the correct waiter
    via a per-``packet_num`` Future.

    Attributes:
        SERVICE_NAME: Service identifier for lockdown-based connections
        RSD_SERVICE_NAME: Service identifier for RSD-based connections
        packet_num: Counter for tracking packet sequence numbers
    """

    SERVICE_NAME = "com.apple.afc"
    RSD_SERVICE_NAME = "com.apple.afc.shim.remote"

    def __init__(self, lockdown: LockdownServiceProvider, service_name: Optional[str] = None):
        """
        Initialize the AFC service.

        :param lockdown: Lockdown service provider for establishing connection
        :param service_name: Optional service name override. Auto-detected if None
        """
        if service_name is None:
            service_name = self.SERVICE_NAME if isinstance(lockdown, LockdownClient) else self.RSD_SERVICE_NAME
        super().__init__(lockdown, service_name)
        self.packet_num = 0
        # Demux state — populated in __aenter__, torn down in __aexit__
        self._afc_pending: dict[int, asyncio.Future[Any]] = {}
        self._afc_write_lock = asyncio.Lock()
        self._afc_reader_task: Optional[asyncio.Task[None]] = None
        # Set (and never cleared) once the connection terminates; the reader task handle
        # itself is not a stable signal because _send_and_wait restarts exited readers.
        self._afc_terminated = asyncio.Event()

    async def __aenter__(self):
        await super().__aenter__()
        self._afc_reader_task = asyncio.create_task(self._afc_reader_loop(), name="afc-reader")
        return self

    async def aclose(self) -> None:
        """Shut down the service: stop the reader task, fail all in-flight requests with
        ``ConnectionTerminatedError``, and close the underlying connection."""
        if self._afc_reader_task is not None:
            self._afc_reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._afc_reader_task
            self._afc_reader_task = None
        for fut in self._afc_pending.values():
            if not fut.done():
                fut.set_exception(ConnectionTerminatedError())
        self._afc_pending.clear()
        await super().close()

    async def __aexit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ):
        await self.aclose()

    async def wait_terminated(self) -> None:
        """Block until the AFC connection terminates (e.g. the device disconnects).

        Ensures the background reader is running so termination is detected even when no
        AFC operation is in flight. Returns immediately if the connection already died.
        """
        if not self._afc_terminated.is_set():
            await self.connect()
            if self._afc_reader_task is None or self._afc_reader_task.done():
                self._afc_reader_task = asyncio.create_task(self._afc_reader_loop(), name="afc-reader")
        await self._afc_terminated.wait()

    async def _afc_reader_loop(self) -> None:
        """Background task: read AFC response packets and route them to waiting callers."""
        try:
            while True:
                header_bytes = await self.service.recvall(afc_header_t.sizeof())
                if not header_bytes:
                    break
                header = afc_header_t.parse(header_bytes)
                assert header.entire_length >= afc_header_t.sizeof()
                length = header.entire_length - afc_header_t.sizeof()
                data = await self.service.recvall(length) if length else b""

                status = AfcError.SUCCESS
                if header.operation == AfcOpcode.STATUS:
                    if length != 8:
                        self.logger.error("Status length != 8")
                    status = afc_error_construct.parse(data)
                elif header.operation != AfcOpcode.DATA:
                    self.logger.debug("Unexpected AFC opcode %s", header.operation)

                fut = self._afc_pending.pop(header.packet_num, None)
                if fut is not None and not fut.done():
                    fut.set_result((status, data))
                else:
                    self.logger.warning("AFC: no waiter for packet_num=%d", header.packet_num)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            # Propagate to all pending waiters so they don't hang
            for fut in self._afc_pending.values():
                if not fut.done():
                    fut.set_exception(e)
            self._afc_pending.clear()
        finally:
            self._afc_terminated.set()

    async def pull(
        self,
        relative_src: str,
        dst: str,
        match: Optional[Pattern[str]] = None,
        callback: Optional[Callable[..., Any]] = None,
        src_dir: str = "",
        ignore_errors: bool = False,
        progress_bar: bool = True,
    ) -> None:
        """
        Pull (download) a file or directory from the device to the local machine.

        The source is resolved through any symbolic link before transfer. A regular file is
        written to ``dst``; if ``dst`` is an existing local directory, the file is placed
        inside it under the source's basename. Files larger than ``MAXIMUM_READ_SIZE`` (4 MB)
        are streamed in chunks. The local file's modification time is set to match the
        device's ``st_mtime``. A directory source is copied recursively into a subdirectory
        of ``dst`` named after the source's basename.

        :param relative_src: Source path on the device, resolved relative to ``src_dir``.
        :param dst: Destination path on the local machine.
        :param match: Optional regex; only entries whose basename matches (via ``search``) are
            copied. Non-matching files are skipped.
        :param callback: Optional callable invoked as ``callback(src, dst)`` after each regular
            file is copied. If it returns an awaitable, the awaitable is awaited.
        :param src_dir: Base directory on the device against which ``relative_src`` is joined.
        :param ignore_errors: If True, per-entry errors during directory recursion are logged
            and skipped instead of propagated.
        :param progress_bar: If True, display a tqdm progress bar while streaming large files.
        """
        src = await self.resolve_path(posixpath.join(src_dir, relative_src))

        if not await self.isdir(src):
            # normal file
            if match is not None and not match.search(posixpath.basename(src)):
                return
            if os.path.isdir(dst):
                dst = os.path.join(dst, os.path.basename(relative_src))
            with open(dst, "wb") as f:
                src_size = (await self.stat(src))["st_size"]
                if src_size <= MAXIMUM_READ_SIZE:
                    contents = await self.get_file_contents(src)
                    f.write(contents)
                else:
                    handle = await self.fopen(src)
                    # Bytes-scaled bar (B/KB/MB with a live rate) rather than a chunk
                    # counter — the rate readout doubles as a transfer benchmark.
                    with tqdm(
                        total=src_size,
                        unit="B",
                        unit_scale=True,
                        unit_divisor=1024,
                        desc=posixpath.basename(src),
                        disable=not progress_bar,
                    ) as pbar:
                        for offset in range(0, src_size, MAXIMUM_READ_SIZE):
                            to_read = min(MAXIMUM_READ_SIZE, src_size - offset)
                            chunk = await self.fread(handle, to_read)
                            f.write(chunk)
                            pbar.update(len(chunk))
                    await self.fclose(handle)
            os.utime(dst, (os.stat(dst).st_atime, (await self.stat(src))["st_mtime"].timestamp()))
            if callback is not None:
                result = callback(src, dst)
                if inspect.isawaitable(result):
                    await result
        else:
            # directory
            dst_path = pathlib.Path(dst) / os.path.basename(relative_src)
            dst_path.mkdir(parents=True, exist_ok=True)

            for filename in await self.listdir(src):
                src_filename = posixpath.join(src, filename)
                dst_filename = dst_path / filename

                src_filename = await self.resolve_path(src_filename)

                if match is not None and not match.search(posixpath.basename(src_filename)):
                    continue

                try:
                    if await self.isdir(src_filename):
                        dst_filename.mkdir(exist_ok=True)
                        await self.pull(
                            src_filename,
                            str(dst_path),
                            match=match,
                            callback=callback,
                            ignore_errors=ignore_errors,
                            progress_bar=progress_bar,
                        )
                        continue

                    await self.pull(
                        src_filename,
                        str(dst_path),
                        match=match,
                        callback=callback,
                        ignore_errors=ignore_errors,
                        progress_bar=progress_bar,
                    )

                except Exception as afc_exception:
                    if not ignore_errors:
                        raise
                    self.logger.warning(f"(Ignoring) Error: {afc_exception} occurred during the copy of {src_filename}")

    @path_to_str()
    async def exists(self, filename: str):
        """
        Check whether a path exists on the device.

        Implemented by attempting `stat`; a missing path is reported as False and any
        other AFC error propagates.

        :param filename: Path to check.
        :return: True if the path exists, False if it was not found.
        """
        try:
            await self.stat(filename)
        except AfcFileNotFoundError:
            return False
        return True

    @path_to_str()
    async def wait_exists(self, filename: str):
        """
        Block until a path exists on the device.

        Polls `exists` every 0.1 seconds until the path appears. Does not return
        until the path exists.

        :param filename: Path to wait for.
        """
        while not await self.exists(filename):
            await asyncio.sleep(0.1)

    @path_to_str()
    async def _push_internal(
        self,
        local_path: str,
        remote_path: str,
        callback: Optional[Callable[[str, str], Any]] = None,
        progress_bar: bool = True,
    ):
        """
        Internal method for pushing files to the device.

        :param local_path: Local file or directory path
        :param remote_path: Remote destination path on the device
        :param callback: Optional callback function called for each file copied (src, dst)
        :param progress_bar: If True, display a tqdm progress bar while streaming large files.
        """
        if callback is not None:
            callback(local_path, remote_path)

        if not os.path.isdir(local_path):
            # normal file
            try:
                if await self.isdir(remote_path):
                    # Remote is dir.
                    remote_path = posixpath.join(remote_path, os.path.basename(local_path))
            except AfcFileNotFoundError:
                # Remote is file.
                remote_parent = posixpath.dirname(remote_path)
                if not await self.exists(remote_parent):
                    raise
                remote_path = posixpath.join(remote_parent, os.path.basename(remote_path))
            src_size = os.path.getsize(local_path)
            if src_size <= MAXIMUM_READ_SIZE:
                with open(local_path, "rb") as f:
                    await self.set_file_contents(remote_path, f.read())
            else:
                # Stream large files in chunks instead of loading them whole into memory,
                # with the same bytes-scaled bar `pull` shows — the live rate readout
                # doubles as a transfer benchmark.
                handle = await self.fopen(remote_path, "w")
                try:
                    with (
                        open(local_path, "rb") as f,
                        tqdm(
                            total=src_size,
                            unit="B",
                            unit_scale=True,
                            unit_divisor=1024,
                            desc=os.path.basename(local_path),
                            disable=not progress_bar,
                        ) as pbar,
                    ):
                        while True:
                            chunk = f.read(MAXIMUM_READ_SIZE)
                            if not chunk:
                                break
                            await self.fwrite(handle, chunk)
                            pbar.update(len(chunk))
                finally:
                    await self.fclose(handle)
        else:
            # directory
            if not await self.exists(remote_path):
                await self.makedirs(remote_path)

            for filename in os.listdir(local_path):
                local_filename = os.path.join(local_path, filename)
                remote_filename = posixpath.join(remote_path, filename).removeprefix("/")

                if os.path.isdir(local_filename):
                    if not await self.exists(remote_filename):
                        await self.makedirs(remote_filename)
                    await self._push_internal(
                        local_filename, remote_filename, callback=callback, progress_bar=progress_bar
                    )
                    continue

                await self._push_internal(local_filename, remote_filename, callback=callback, progress_bar=progress_bar)

    @path_to_str()
    async def push(
        self,
        local_path: str,
        remote_path: str,
        callback: Optional[Callable[[str, str], Any]] = None,
        progress_bar: bool = True,
    ):
        """
        Push (upload) a file or directory from the local machine to the device.

        A regular file is written to ``remote_path`` (or, if ``remote_path`` is an existing
        remote directory, into it under the file's basename). Files larger than
        ``MAXIMUM_READ_SIZE`` (4 MB) are streamed in chunks with a byte-scaled progress bar.
        A local directory is copied recursively into ``remote_path``/<basename of local_path>,
        creating remote directories as needed.

        :param local_path: Source path on the local machine.
        :param remote_path: Destination path on the device.
        :param callback: Optional callable invoked as ``callback(local_path, remote_path)``
            before each entry is transferred.
        :param progress_bar: If True, display a tqdm progress bar while streaming large files.
        """
        if os.path.isdir(local_path):
            remote_path = posixpath.join(remote_path, os.path.basename(local_path))
        await self._push_internal(local_path, remote_path, callback, progress_bar=progress_bar)

    @path_to_str()
    async def rm_single(self, filename: str, force: bool = False) -> bool:
        """
        Remove a single file or empty directory on the device.

        Issues a single ``REMOVE_PATH`` operation; it does not recurse into a non-empty
        directory.

        :param filename: Path to the file or directory to remove.
        :param force: If True, swallow an `AfcException` and return False instead of raising.
        :return: True on success; False if the removal failed and ``force`` is True.
        :raises AfcException: if the removal fails and ``force`` is False.
        """
        try:
            await self._do_operation(
                AfcOpcode.REMOVE_PATH, afc_rm_req_t.build(AfcRmRequest(filename=filename)), filename
            )
        except AfcException:
            if force:
                return False
            raise
        return True

    @path_to_str()
    async def rm(self, filename: str, match: Optional[Pattern[str]] = None, force: bool = False) -> list[str]:
        """
        Recursively remove a file or directory tree on the device.

        For a directory, every entry is removed depth-first and the directory itself is removed
        last. The ``match`` pattern, when given, filters which top-level entries of ``filename``
        are considered (matched against their basename via ``match``); nested entries are always
        removed once their parent is selected.

        :param filename: Path to the file or directory to remove.
        :param match: Optional regex; only directory entries whose basename matches are removed.
            None removes all entries.
        :param force: If True, suppress the final `AfcException` and instead return the
            list of paths that could not be deleted.
        :return: List of paths that could not be deleted (empty on full success).
        :raises AfcException: if any path could not be deleted and ``force`` is False.
        """
        if not await self.exists(filename) and not await self.rm_single(filename, force=force):
            return [filename]

        # single file
        if not await self.isdir(filename):
            if await self.rm_single(filename, force=force):
                return []
            return [filename]

        # directory content
        undeleted_items: list[str] = []
        for entry in await self.listdir(filename):
            current_filename = posixpath.join(filename, entry)

            if match is not None and not match.match(posixpath.basename(current_filename)):
                continue

            if await self.isdir(current_filename):
                ret_undeleted_items = await self.rm(current_filename, force=True)
                undeleted_items.extend(ret_undeleted_items)
            else:
                if not await self.rm_single(current_filename, force=True):
                    undeleted_items.append(current_filename)

        # directory path
        try:
            if not await self.rm_single(filename, force=force):
                undeleted_items.append(filename)
                return undeleted_items
        except AfcException:
            if undeleted_items:
                undeleted_items.append(filename)
            else:
                raise

        if undeleted_items:
            # AfcException mis-annotates `status` as str; it accepts AfcError/None at runtime
            raise AfcException(
                f"Failed to delete paths: {undeleted_items}",
                None,
            )

        return []

    async def get_device_info(self):
        """
        Query device file-system information.

        Issues a ``GET_DEVINFO`` operation and decodes the null-terminated key/value list into
        a dictionary (e.g. model, total/free bytes, block size).

        :return: Dictionary of device file-system attributes (all values are strings).
        """
        return list_to_dict(await self._do_operation(AfcOpcode.GET_DEVINFO))

    @path_to_str()
    async def listdir(self, filename: str) -> list[str]:
        """
        List the entries of a directory on the device.

        :param filename: Path to the directory.
        :return: Entry names in the directory, excluding ``.`` and ``..``.
        :raises AfcFileNotFoundError: if the path does not exist.
        :raises AfcException: if the path is not a directory or cannot be listed.
        """
        data = await self._do_operation(
            AfcOpcode.READ_DIR, afc_read_dir_req_t.build(AfcReadDirRequest(filename=filename)), filename
        )
        return afc_read_dir_resp_t.parse(data).filenames[2:]  # skip the . and ..

    @path_to_str()
    async def makedirs(self, filename: str):
        """
        Create a directory on the device.

        Issues a ``MAKE_DIR`` operation, creating any missing parent directories.

        :param filename: Path of the directory to create.
        :return: Raw response payload from the operation (typically empty).
        :raises AfcException: if the directory could not be created.
        """
        return await self._do_operation(
            AfcOpcode.MAKE_DIR, afc_mkdir_req_t.build(AfcMkdirRequest(filename=filename)), filename
        )

    @path_to_str()
    async def isdir(self, filename: str) -> bool:
        """
        Check whether a path is a directory.

        Stats the path and tests whether its ``st_ifmt`` is ``S_IFDIR``.

        :param filename: Path to check.
        :return: True if the path is a directory, False otherwise.
        :raises AfcFileNotFoundError: if the path does not exist.
        """
        stat = await self.stat(filename)
        return stat.get("st_ifmt") == "S_IFDIR"

    @path_to_str()
    async def stat(self, filename: str) -> dict[str, Any]:
        """
        Get file or directory metadata.

        Issues a ``GET_FILE_INFO`` operation and returns the decoded attribute dictionary.
        Numeric fields (``st_size``, ``st_blocks``, ``st_nlink``) are converted to ints;
        ``st_mtime`` and ``st_birthtime`` are converted from device nanosecond timestamps to
        `datetime`. A ``st_ifmt`` entry (e.g. ``S_IFREG``, ``S_IFDIR``,
        ``S_IFLNK``) describes the file type, and symbolic links also carry a ``LinkTarget``.

        :param filename: Path to the file or directory.
        :return: Dictionary of file attributes.
        :raises AfcFileNotFoundError: if the path does not exist (AFC ``READ_ERROR``).
        :raises AfcException: for any other failure status.
        """
        try:
            stat: dict[str, Any] = list_to_dict(
                await self._do_operation(
                    AfcOpcode.GET_FILE_INFO, afc_stat_t.build(AfcStatRequest(filename=filename)), filename
                )
            )
        except AfcException as e:
            if e.status != AfcError.READ_ERROR:
                raise
            raise AfcFileNotFoundError(e.args[0], e.status) from e

        stat["st_size"] = int(stat["st_size"])
        stat["st_blocks"] = int(stat["st_blocks"])
        stat["st_mtime"] = int(stat["st_mtime"])
        stat["st_birthtime"] = int(stat["st_birthtime"])
        stat["st_nlink"] = int(stat["st_nlink"])
        stat["st_mtime"] = datetime.fromtimestamp(stat["st_mtime"] / (10**9))
        stat["st_birthtime"] = datetime.fromtimestamp(stat["st_birthtime"] / (10**9))
        return stat

    @path_to_str()
    async def os_stat(self, path: str):
        """
        Get file statistics as an `stat`-style result.

        Wraps `stat`, mapping the AFC ``st_ifmt`` to a numeric mode and packing the
        attributes into a `StatResult` namedtuple. ``st_ino`` is synthesized from the
        normalized path, ``st_uid``/``st_gid``/``st_dev`` are reported as 0 and ``st_blksize``
        as 4096 (AFC does not expose these). ``st_atime`` mirrors ``st_mtime``.

        :param path: Path to the file or directory.
        :return: A `StatResult` namedtuple.
        :raises AfcFileNotFoundError: if the path does not exist.
        """
        stat = await self.stat(path)
        mode = 0
        for s_mode in ["S_IFDIR", "S_IFCHR", "S_IFBLK", "S_IFREG", "S_IFIFO", "S_IFLNK", "S_IFSOCK"]:
            if stat["st_ifmt"] == s_mode:
                mode = getattr(stat_module, s_mode)
        return StatResult(
            mode,
            hash(posixpath.normpath(path)),
            0,
            stat["st_nlink"],
            0,
            0,
            stat["st_size"],
            stat["st_mtime"].timestamp(),
            stat["st_mtime"].timestamp(),
            stat["st_birthtime"].timestamp(),
            stat["st_blocks"],
            4096,
            stat["st_birthtime"].timestamp(),
        )

    @path_to_str()
    async def link(self, target: str, source: str, type_: AfcLinkType = AfcLinkType.SYMLINK):
        """
        Create a symbolic or hard link on the device.

        :param target: Path the link points to.
        :param source: Path at which the link is created.
        :param type_: `AfcLinkType` to create (``SYMLINK`` by default, or ``HARDLINK``).
        :return: Raw response payload from the operation (typically empty).
        :raises AfcException: if the link could not be created.
        """
        return await self._do_operation(
            AfcOpcode.MAKE_LINK,
            afc_make_link_req_t.build(AfcMakeLinkRequest(type=type_, target=target, source=source)),
        )

    @path_to_str()
    async def fopen(self, filename: str, mode: str = "r") -> int:
        """
        Open a file on the device and return its handle.

        :param filename: Path to the file.
        :param mode: Textual open mode; one of ``'r'``, ``'r+'``, ``'w'``, ``'w+'``, ``'a'``,
            ``'a+'`` (mapped to the corresponding AFC fopen mode).
        :return: Integer handle usable with `fread`, `fwrite`, `lock` and
            `fclose`.
        :raises ArgumentError: if ``mode`` is not one of the supported textual modes.
        :raises AfcException: if the file could not be opened.
        """
        if mode not in AFC_FOPEN_TEXTUAL_MODES:
            raise ArgumentError(f"mode can be only one of: {AFC_FOPEN_TEXTUAL_MODES.keys()}")

        data = await self._do_operation(
            AfcOpcode.FILE_OPEN,
            afc_fopen_req_t.build(
                AfcFopenRequest(mode=AFC_FOPEN_TEXTUAL_MODES[mode], filename=filename),
            ),
        )
        return afc_fopen_resp_t.parse(data).handle

    async def fclose(self, handle: int):
        """
        Close an open file handle.

        :param handle: Handle returned by `fopen`.
        :return: Raw response payload from the operation (typically empty).
        :raises AfcException: if the close operation fails.
        """
        return await self._do_operation(AfcOpcode.FILE_CLOSE, afc_fclose_req_t.build(AfcFcloseRequest(handle=handle)))

    @path_to_str()
    async def rename(self, source: str, target: str) -> None:
        """
        Rename or move a file or directory on the device.

        :param source: Current path of the file or directory.
        :param target: New path for the file or directory.
        :raises AfcFileNotFoundError: if the operation fails and ``source`` no longer exists.
        :raises AfcException: if the operation fails while ``source`` still exists.
        """
        try:
            await self._do_operation(
                AfcOpcode.RENAME_PATH,
                afc_rename_req_t.build(AfcRenameRequest(source=source, target=target)),
            )
        except AfcException as e:
            if await self.exists(source):
                raise
            raise AfcFileNotFoundError(
                f"Failed to rename {source} into {target}. Got status: {e.status}", e.args[0], str(e.status)
            ) from e

    async def fread(self, handle: int, sz: int) -> bytes:
        """
        Read data from an open file handle.

        Automatically handles large reads by splitting into multiple operations.
        Each chunk send+receive is performed atomically via the demux reader so
        concurrent callers on the same AfcService instance are safe.

        :param handle: Handle returned by `fopen`.
        :param sz: Number of bytes to read. Reads larger than ``MAXIMUM_READ_SIZE`` (4 MB) are
            split into successive operations.
        :return: The bytes read.
        :raises AfcException: if any read operation returns a non-success status.
        """
        data = b""
        while sz > 0:
            to_read = MAXIMUM_READ_SIZE if sz > MAXIMUM_READ_SIZE else sz
            status, chunk = await self._send_and_wait(
                AfcOpcode.READ, afc_fread_req_t.build(AfcFreadRequest(handle=handle, size=to_read))
            )
            if status != AfcError.SUCCESS:
                raise AfcException("fread error", status)
            sz -= to_read
            data += chunk
        return data

    async def fseek(self, handle: int, offset: int, whence: int = os.SEEK_SET) -> None:
        """
        Seek within an open file handle.

        :param handle: Handle returned by `fopen`.
        :param offset: Byte offset relative to ``whence``.
        :param whence: One of ``os.SEEK_SET`` (0), ``os.SEEK_CUR`` (1), ``os.SEEK_END`` (2).
        :raises AfcException: if the seek operation fails.
        """
        await self._do_operation(
            AfcOpcode.FILE_SEEK,
            afc_fseek_req_t.build(AfcFileSeekRequest(handle=handle, whence=whence, offset=offset)),
        )

    async def fwrite(self, handle: int, data: bytes, chunk_size: int = MAXIMUM_WRITE_SIZE) -> None:
        """
        Write data to an open file handle.

        Automatically handles large writes by splitting into multiple operations.
        Each chunk send+receive is performed atomically via the demux reader so
        concurrent callers on the same AfcService instance are safe.

        :param handle: Handle returned by `fopen`.
        :param data: Bytes to write.
        :param chunk_size: Maximum bytes per ``WRITE`` operation (default ``MAXIMUM_WRITE_SIZE``).
        :raises AfcException: if any write operation returns a non-success status.
        """
        file_handle = struct.pack("<Q", handle)
        chunks_count = len(data) // chunk_size
        for i in range(chunks_count):
            chunk = data[i * chunk_size : (i + 1) * chunk_size]
            status, _ = await self._send_and_wait(AfcOpcode.WRITE, file_handle + chunk, this_length=48)
            if status != AfcError.SUCCESS:
                raise AfcException(f"failed to write chunk: {status}", status)

        if len(data) % chunk_size:
            chunk = data[chunks_count * chunk_size :]
            status, _ = await self._send_and_wait(AfcOpcode.WRITE, file_handle + chunk, this_length=48)
            if status != AfcError.SUCCESS:
                raise AfcException(f"failed to write last chunk: {status}", status)

    @path_to_str()
    async def resolve_path(self, filename: str) -> str:
        """
        Resolve a symbolic link to its target path.

        Stats the path; if it is a symbolic link, returns its ``LinkTarget`` (joined against
        the link's parent directory when the target is relative). Non-links are returned
        unchanged. Only a single level of link is resolved.

        :param filename: Path to resolve.
        :return: The link target, or ``filename`` unchanged if it is not a symbolic link.
        :raises AfcFileNotFoundError: if the path does not exist.
        """
        info = await self.stat(filename)
        if info["st_ifmt"] == "S_IFLNK":
            target = info["LinkTarget"]
            filename = posixpath.join(posixpath.dirname(filename), target) if not target.startswith("/") else target
        return filename

    @path_to_str()
    async def get_file_contents(self, filename: str) -> bytes:
        """
        Read and return the entire contents of a file.

        Resolves any symbolic link, verifies the target is a regular file, then opens it,
        reads ``st_size`` bytes and closes the handle.

        :param filename: Path to the file.
        :return: The file contents as bytes.
        :raises AfcException: if the path is not a regular file (``S_IFREG``) or could not be opened.
        :raises AfcFileNotFoundError: if the path does not exist.
        """
        filename = await self.resolve_path(filename)
        info = await self.stat(filename)

        if info["st_ifmt"] != "S_IFREG":
            raise AfcException(f"{filename} isn't a file", AfcError.INVALID_ARG, filename)

        h = await self.fopen(filename)
        if not h:
            raise AfcException(f"failed to open {filename}", AfcError.INTERNAL_ERROR, filename)
        d = await self.fread(h, int(info["st_size"]))
        await self.fclose(h)
        return d

    @path_to_str()
    async def set_file_contents(self, filename: str, data: bytes) -> None:
        """
        Write data to a file, creating or truncating it.

        Opens the file in ``'w'`` mode (create/truncate), writes ``data`` and closes the handle.

        :param filename: Path to the file.
        :param data: Bytes to write.
        :raises AfcException: if the open or write operation fails.
        """
        h = await self.fopen(filename, "w")
        await self.fwrite(h, data)
        await self.fclose(h)

    @path_to_str()
    async def walk(self, dirname: str) -> AsyncIterator[tuple[str, list[str], list[str]]]:
        """
        Recursively walk a directory tree, similar to `walk`.

        Yields one ``(dirpath, dirnames, filenames)`` tuple per directory, top-down, starting
        at ``dirname``. ``dirnames`` lists subdirectory names and ``filenames`` lists all other
        entries. Symbolic links to directories are classified as files (not descended into).

        :param dirname: Root directory to walk.
        :yields: ``(dirpath, dirnames, filenames)`` tuples.
        """
        dirs: list[str] = []
        files: list[str] = []
        for fd in await self.listdir(dirname):
            if fd in (".", "..", ""):
                continue
            infos = await self.stat(posixpath.join(dirname, fd))
            if infos and infos.get("st_ifmt") == "S_IFDIR":
                dirs.append(fd)
            else:
                files.append(fd)

        yield dirname, dirs, files

        if dirs:
            for d in dirs:
                async for item in self.walk(posixpath.join(dirname, d)):
                    yield item

    @path_to_str()
    async def dirlist(self, root: str, depth: int = -1) -> AsyncIterator[str]:
        """
        Recursively yield paths under a directory up to a maximum depth.

        Yields ``root`` itself first, followed by the full path of every entry found while
        walking, pruning descent once a directory's depth (in path separators) reaches
        ``depth``.

        :param root: Root directory to list.
        :param depth: Maximum traversal depth; ``-1`` for unlimited, ``0`` to yield only ``root``.
        :yields: Full paths of files and directories.
        """
        async for folder, dirs, files in self.walk(root):
            if folder == root:
                yield folder
                if depth == 0:
                    break
            if folder != root and depth != -1 and folder.count(posixpath.sep) >= depth:
                continue
            for entry in dirs + files:
                yield posixpath.join(folder, entry)

    async def lock(self, handle: int, operation: int):
        """
        Apply or release an advisory ``flock``-style lock on an open file.

        :param handle: Handle returned by `fopen`.
        :param operation: Lock operation, one of ``AFC_LOCK_SH`` (shared), ``AFC_LOCK_EX``
            (exclusive) or ``AFC_LOCK_UN`` (unlock).
        :return: Raw response payload from the operation (typically empty).
        :raises AfcException: if the lock operation fails.
        """
        return await self._do_operation(
            AfcOpcode.FILE_LOCK, afc_lock_t.build(AfcLockRequest(handle=handle, op=operation))
        )

    async def _dispatch_packet(self, operation: AfcOpcode, data: bytes, this_length: int = 0) -> int:
        """
        Send an AFC protocol packet to the device.

        :param operation: AFC operation code
        :param data: Packet payload data
        :param this_length: Override for the packet length field (0 for auto-calculation)
        :return: The packet_num assigned to this packet (used to match the response)
        """
        pkt_num = self.packet_num
        entire_length = afc_header_t.sizeof() + len(data)
        header = afc_header_t.build(
            AfcHeader(
                entire_length=entire_length,
                this_length=this_length or entire_length,
                packet_num=pkt_num,
                operation=operation,
            )
        )
        self.packet_num += 1
        await self.service.sendall(header + data)
        return pkt_num

    async def _receive_data(self):
        """
        Receive an AFC protocol response packet from the device.

        .. deprecated::
            Internal use only. External callers should use `_do_operation` or
            `_send_and_wait` which use the background demux reader.

        :return: Tuple of (status_code, response_data)
        """
        header_bytes = await self.service.recvall(afc_header_t.sizeof())
        status = AfcError.SUCCESS
        data = b""
        if header_bytes:
            header = afc_header_t.parse(header_bytes)
            assert header.entire_length >= afc_header_t.sizeof()
            length = header.entire_length - afc_header_t.sizeof()
            data = await self.service.recvall(length)
            if header.operation == AfcOpcode.STATUS:
                if length != 8:
                    self.logger.error("Status length != 8")
                status = afc_error_construct.parse(data)
            elif header.operation != AfcOpcode.DATA:
                self.logger.debug("Unexpected AFC opcode %s", header.operation)
        return status, data

    async def _send_and_wait(self, operation: AfcOpcode, data: bytes, this_length: int = 0):
        """
        Atomically send one AFC packet and wait for its response via the demux reader.

        The write lock ensures that ``packet_num`` assignment, Future registration, and
        the actual ``sendall`` are an uninterruptible unit so the background reader always
        finds a registered Future before the response arrives.

        If the background reader task has not been started yet (e.g. when the service is
        used without ``async with``), it is started lazily on the first call.

        :param operation: AFC operation code
        :param data: Packet payload
        :param this_length: Override for the ``this_length`` header field
        :return: Tuple of (AfcError, response_bytes)
        """
        # Ensure we're connected (lazy connect for non-async-with usage)
        await self.connect()
        # Start background reader lazily for callers that don't use async with.
        # Also restart it if it exited (e.g. connection error): the new task will
        # fail immediately on the broken socket and propagate the error to the caller
        # via _afc_pending, giving a clean exception rather than an infinite hang.
        if self._afc_reader_task is None or self._afc_reader_task.done():
            self._afc_reader_task = asyncio.create_task(self._afc_reader_loop(), name="afc-reader")
        loop = asyncio.get_event_loop()
        async with self._afc_write_lock:
            fut: asyncio.Future[Any] = loop.create_future()
            # Register *before* sending so the reader never misses the response
            pkt_num = self.packet_num
            self._afc_pending[pkt_num] = fut
            try:
                await self._dispatch_packet(operation, data, this_length)
            except BaseException:
                self._afc_pending.pop(pkt_num, None)
                raise
        return await fut

    async def _do_operation(self, opcode: AfcOpcode, data: bytes = b"", filename: Optional[str] = None) -> bytes:
        """
        Performs a low-level operation using the specified opcode and additional data.

        This method dispatches a packet with the given opcode and data, waits for a
        response via the background demux reader, and processes the result to determine
        success or failure. Multiple callers may call this concurrently on the same
        instance; each operation is matched to its response by ``packet_num``.

        :param opcode: The operation code specifying the type of operation to perform.
        :param data: The additional data to send along with the operation. Defaults to an empty byte string.
        :param filename: The filename associated with the operation, if applicable. Defaults to None.

        :returns: bytes: The data received as a response to the operation.

        :raises:
            AfcException: General exception raised if the operation fails with an
                          unspecified error status.
            AfcFileNotFoundError: Exception raised when the operation fails due to
                                  an object not being found (e.g., file or directory).
        """
        status, data = await self._send_and_wait(opcode, data)

        exception = AfcException
        if status != AfcError.SUCCESS:
            if status == AfcError.OBJECT_NOT_FOUND:
                exception = AfcFileNotFoundError

            opcode_name = opcode.name
            message = f"Opcode: {opcode_name} failed with status: {status}"
            if filename is not None:
                message += f" for file: {filename}"
            # AfcException mis-annotates `status` as str; it accepts AfcError/None at runtime
            raise exception(message, status, filename)

        return data


class AfcLsStub(LsStub):
    """
    Adapter class to make AfcShell compatible with pygnuutils ls implementation.

    This stub provides an interface between the pygnuutils Ls class and the AFC
    file system, translating calls to work with remote device paths.
    """

    def __init__(self, afc_shell: "AfcShell", stdout: Optional[TextIO] = sys.stdout):
        """
        Initialize the ls stub.

        :param afc_shell: AfcShell instance providing device access
        :param stdout: Output stream for ls results
        """
        self.afc_shell = afc_shell
        self.stdout = stdout

    @property
    def sep(self):
        return posixpath.sep

    def join(self, path: str, *paths: str):
        return posixpath.join(path, *paths)

    def abspath(self, path: str):
        return posixpath.normpath(path)

    def stat(self, path: str, dir_fd: Optional[int] = None, follow_symlinks: bool = True):
        if follow_symlinks:
            path = self.afc_shell.afc.resolve_path(path)
        return self.afc_shell.afc.os_stat(path)

    def readlink(self, path: str, dir_fd: Optional[int] = None):
        return self.afc_shell.afc.resolve_path(path)

    def isabs(self, path: str):
        return posixpath.isabs(path)

    def dirname(self, path: str):
        return posixpath.dirname(path)

    def basename(self, path: str):
        return posixpath.basename(path)

    def getgroup(self, st_gid: int):
        return "-"

    def getuser(self, st_uid: int):
        return "-"

    def now(self):
        timestamp = self.afc_shell.lockdown.all_values.get("TimeIntervalSince1970", 0)
        return datetime.fromtimestamp(timestamp)

    def listdir(self, path: str = "."):
        return self.afc_shell.afc.listdir(path)

    def system(self):
        return "Darwin"

    def getenv(self, key: str, default: Optional[str] = None):
        return ""

    def print(self, *objects: Any, sep: str = " ", end: str = "\n", file: TextIO = sys.stdout, flush: bool = False):
        """
        Print ls output to the constructor-provided stream.

        The fourth argument is accepted only for compatibility with Python's
        ``print(file=...)`` style calls used by ``pygnuutils``. It is ignored.
        Output is suppressed when ``self.stdout`` is ``None``.
        """
        if self.stdout is None:
            return
        print(*objects, sep=sep, end=end, file=self.stdout, flush=flush)

    def get_tty_width(self):
        return os.get_terminal_size().columns


class _AsyncRunner:
    """Run async coroutines on the shared CLI event loop."""

    def __init__(self) -> None:
        self._loop = get_asyncio_loop()
        self._lock = threading.Lock()

    def run(self, coro: Any):
        with self._lock:
            if self._loop.is_running():
                loop_thread_id = getattr(self._loop, "_thread_id", None)
                if loop_thread_id == threading.get_ident():
                    raise RuntimeError("Cannot run blocking AFC shell command inside the running event loop thread")
                fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
                return fut.result()
            return self._loop.run_until_complete(coro)

    def stop(self) -> None:
        # The CLI event loop is process-global and managed elsewhere.
        return


class _SyncAsyncGenIterator:
    """Bridge an async generator into a blocking iterator for xonsh handlers."""

    def __init__(self, agen: Any, lock: threading.Lock, runner: _AsyncRunner):
        self._agen = agen
        self._lock = lock
        self._runner = runner

    def __iter__(self) -> "_SyncAsyncGenIterator":
        return self

    def __next__(self):
        with self._lock:
            try:
                return self._runner.run(self._agen.__anext__())
            except StopAsyncIteration as e:
                raise StopIteration from e


class _SyncAfcProxy:
    """Expose AfcService async methods as blocking calls for legacy shell handlers."""

    def __init__(self, afc: AfcService):
        self._afc = afc
        self._lock = threading.Lock()
        self._runner = _AsyncRunner()

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._afc, name)
        if not callable(attr):
            return attr

        def sync_call(*args: Any, **kwargs: Any):
            result = attr(*args, **kwargs)
            if inspect.isasyncgen(result):
                return _SyncAsyncGenIterator(result, self._lock, self._runner)
            if inspect.isawaitable(result):
                with self._lock:
                    try:
                        return self._runner.run(result)
                    except Exception:
                        # Avoid "coroutine was never awaited" warnings when execution
                        # is rejected (e.g. completion from a running event loop thread).
                        if asyncio.iscoroutine(result):
                            result.close()
                        raise
            return result

        return sync_call


def path_completer(xsh: Any, action: Any, completer: Any, alias: Any, command: Any) -> list[str]:
    """
    Provide path completion for xonsh shell commands.

    Generates completion suggestions based on the current working directory
    and available files/directories on the device.

    :param xsh: Xonsh shell instance
    :param action: Completion action
    :param completer: Completer instance
    :param alias: Command alias
    :param command: Command being completed
    :return: List of completion suggestions
    """
    shell = cast(AfcShell, _xsh_ctx()["_shell"])
    pwd = shell.cwd
    is_absolute = command.prefix.startswith("/")
    dirpath = posixpath.join(pwd, command.prefix)
    try:
        if not shell.afc.exists(dirpath):
            dirpath = posixpath.dirname(dirpath)
        shell._refresh_completion_cache_sync(dirpath)
    except RuntimeError:
        # prompt_toolkit completion runs inside an active loop thread where we
        # cannot block for device I/O. Use cached entries and refresh in background.
        shell._schedule_completion_cache_refresh(dirpath)
        if not shell._get_completion_cache(dirpath):
            dirpath = posixpath.dirname(dirpath)
            shell._schedule_completion_cache_refresh(dirpath)

    result: list[str] = []
    for f, is_dir in shell._get_completion_cache(dirpath):
        if is_absolute:
            completion_option = posixpath.join(dirpath, f)
        else:
            completion_option = posixpath.relpath(posixpath.join(dirpath, f), pwd)
        if is_dir:
            result.append(f"{completion_option}/")
        else:
            result.append(completion_option)
    return result


def dir_completer(xsh: Any, action: Any, completer: Any, alias: Any, command: Any):
    """
    Provide directory-only completion for xonsh shell commands.

    Similar to path_completer but only suggests directories, not files.

    :param xsh: Xonsh shell instance
    :param action: Completion action
    :param completer: Completer instance
    :param alias: Command alias
    :param command: Command being completed
    :return: List of directory completion suggestions
    """
    shell = cast(AfcShell, _xsh_ctx()["_shell"])
    pwd = shell.cwd
    is_absolute = command.prefix.startswith("/")
    dirpath = posixpath.join(pwd, command.prefix)
    try:
        if not shell.afc.exists(dirpath):
            dirpath = posixpath.dirname(dirpath)
        shell._refresh_completion_cache_sync(dirpath)
    except RuntimeError:
        # prompt_toolkit completion runs inside an active loop thread where we
        # cannot block for device I/O. Use cached entries and refresh in background.
        shell._schedule_completion_cache_refresh(dirpath)
        if not shell._get_completion_cache(dirpath):
            dirpath = posixpath.dirname(dirpath)
            shell._schedule_completion_cache_refresh(dirpath)

    result: list[str] = []
    for f, is_dir in shell._get_completion_cache(dirpath):
        if not is_dir:
            continue
        if is_absolute:
            completion_option = posixpath.join(dirpath, f)
        else:
            completion_option = posixpath.relpath(posixpath.join(dirpath, f), pwd)
        result.append(f"{completion_option}/")
    return result


# xonsh declares Arg(completer=...) as returning Iterator[str], but any iterable works at
# runtime; adapt the list-returning completers' declared type once here instead of per call site.
_path_arg_completer = cast(Callable[..., Iterator[str]], path_completer)
_dir_arg_completer = cast(Callable[..., Iterator[str]], dir_completer)


class AfcShell:
    """
    Interactive xonsh-based shell for navigating an iOS device's file system via AFC.

    Provides a familiar shell environment with common commands (ls, cd, cat, etc.)
    that operate on the remote device's file system. The shell is powered by xonsh
    and includes features like tab completion, history, and command aliases.

    Attributes:
        lockdown: Lockdown service provider for device communication
        afc: AfcService instance for file operations
        cwd: Current working directory on the device
    """

    @classmethod
    def create(
        cls,
        service_provider: LockdownServiceProvider,
        service_name: Optional[str] = None,
        service: Optional[LockdownService] = None,
        auto_cd: Optional[str] = "/",
    ):
        """
        Create and launch an AFC shell session.

        This class method sets up the xonsh environment and starts an interactive
        shell session for navigating the device's file system.

        :param service_provider: Lockdown service provider for device connection
        :param service_name: Optional AFC service name override
        :param service: Optional pre-initialized AFC service instance
        :param auto_cd: Initial working directory (default: "/")
        """
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        args = ["--rc", str(pathlib.Path(__file__).absolute())]
        os.environ["XONSH_COLOR_STYLE"] = "default"
        _xsh_ctx()["_class"] = cls
        _xsh_ctx()["_lockdown"] = service_provider
        _xsh_ctx()["_auto_cd"] = auto_cd
        if service is not None:
            _xsh_ctx()["_service"] = service
        else:
            _xsh_ctx()["_service"] = AfcService(service_provider, service_name=service_name)

        try:
            logging.getLogger("parso").setLevel(logging.CRITICAL + 1)
            xonsh_main(args)
        except SystemExit:
            pass

    def __init__(self, lockdown: LockdownServiceProvider, service: AfcService):
        """
        Initialize the AFC shell.

        Sets up the shell environment, registers commands, and configures the prompt.
        This is called internally by the create() class method.

        :param lockdown: Lockdown service provider for device communication
        :param service: AFC service instance for file operations
        """
        self.lockdown = lockdown
        self.afc = _SyncAfcProxy(service)
        _xsh_ctx()["_shell"] = self
        self.cwd: str = _xsh_ctx().get("_auto_cd", "/")
        self._commands: dict[str, Any] = {}
        self._orig_aliases: dict[str, Any] = {}
        assert cast(Any, XSH).env is not None
        self._orig_prompt = cast(Any, XSH).env["PROMPT"]
        self._completion_cache: dict[str, list[tuple[str, bool]]] = {}
        self._completion_refreshing: set[str] = set()
        self._completion_cache_lock = threading.Lock()
        self._setup_shell_commands()
        self._schedule_completion_cache_refresh(self.cwd)

        print_color("""
        {BOLD_WHITE}Welcome to xonsh-afc shell! 👋{RESET}
        Use {CYAN}show-help{RESET} to view a list of all available special commands.
            These special commands will replace all already existing commands.
        """)

    def _set_completion_cache(self, directory: str, entries: list[tuple[str, bool]]) -> None:
        with self._completion_cache_lock:
            self._completion_cache[directory] = entries
            self._completion_refreshing.discard(directory)

    def _get_completion_cache(self, directory: str) -> list[tuple[str, bool]]:
        with self._completion_cache_lock:
            return list(self._completion_cache.get(directory, []))

    def _refresh_completion_cache_sync(self, directory: str) -> None:
        entries: list[tuple[str, bool]] = []
        for name in self.afc.listdir(directory):
            is_dir = False
            with contextlib.suppress(AfcException):
                is_dir = self.afc.isdir(posixpath.join(directory, name))
            entries.append((name, is_dir))
        self._set_completion_cache(directory, entries)

    def _schedule_completion_cache_refresh(self, directory: str) -> None:
        """
        Schedules a refresh of the completion cache for a given directory in a separate thread.

        This method ensures that completion cache updates for the specified directory are
        processed without blocking the main thread. It uses a lock to avoid concurrent
        cache updates for the same directory. Threads are created in a daemon mode,
        allowing them to terminate when the main program exits.

        Parameters:
        directory : str
            The path of the directory for which the completion cache should be refreshed.
        """
        with self._completion_cache_lock:
            if directory in self._completion_refreshing:
                return
            self._completion_refreshing.add(directory)

        def _refresh() -> None:
            try:
                self._refresh_completion_cache_sync(directory)
            except Exception:
                with self._completion_cache_lock:
                    self._completion_refreshing.discard(directory)

        threading.Thread(target=_refresh, daemon=True).start()

    def _register_arg_parse_alias(self, name: str, handler: Union[Callable[..., Any], str]):
        """
        Register a command with argument parsing support.

        :param name: Command name
        :param handler: Command handler function or string
        """
        handler = ArgParserAlias(func=handler, has_args=True, prog=name)
        self._commands[name] = handler
        aliases = cast(Any, XSH).aliases
        assert aliases is not None
        if aliases.get(name):
            self._orig_aliases[name] = aliases[name]
        aliases[name] = handler

    def _register_rpc_command(self, name: str, handler: Union[Callable[..., Any], str]):
        """
        Register a simple command without argument parsing.

        :param name: Command name
        :param handler: Command handler function or executable path
        """
        self._commands[name] = handler
        aliases = cast(Any, XSH).aliases
        assert aliases is not None
        if aliases.get(name):
            self._orig_aliases[name] = aliases[name]
        aliases[name] = handler

    def _setup_shell_commands(self):
        """
        Initialize all shell commands and configure the shell environment.

        Clears the PATH to prevent host command execution (except for specific
        utilities), registers AFC-specific commands, and sets up the custom prompt.
        """
        # clear all host commands except for some useful ones
        env = cast(Any, XSH).env
        assert env is not None
        # Env.__getitem__ is untyped; $PATH is an EnvPath (mutable sequence) at runtime
        cast(MutableSequence[str], env["PATH"]).clear()
        # adding "file" just to fix xonsh errors
        for cmd in ["wc", "grep", "egrep", "sed", "awk", "print", "yes", "cat"]:
            executable = shutil.which(cmd)
            if executable is not None:
                self._register_rpc_command(cmd, executable)

        self._register_rpc_command("ls", self.do_ls)
        self._register_arg_parse_alias("pwd", self._do_pwd)
        self._register_arg_parse_alias("link", self._do_link)
        self._register_arg_parse_alias("cd", self._do_cd)
        self._register_arg_parse_alias("cat", self._do_cat)
        self._register_arg_parse_alias("rm", self._do_rm)
        self._register_arg_parse_alias("pull", self._do_pull)
        self._register_arg_parse_alias("push", self._do_push)
        self._register_arg_parse_alias("walk", self._do_walk)
        self._register_arg_parse_alias("head", self._do_head)
        self._register_arg_parse_alias("hexdump", self._do_hexdump)
        self._register_arg_parse_alias("mkdir", self._do_mkdir)
        self._register_arg_parse_alias("info", self._do_info)
        self._register_arg_parse_alias("mv", self._do_mv)
        self._register_arg_parse_alias("stat", self._do_stat)
        self._register_arg_parse_alias("show-help", self._do_show_help)

        env["PROMPT"] = f"[{{BOLD_CYAN}}{self.afc.service_name}:{{afc_cwd}}{{RESET}}]{{prompt_end}} "
        # Env.__getitem__ is untyped; $PROMPT_FIELDS is a PromptFields (mutable mapping) at runtime
        prompt_fields = cast(MutableMapping[str, Any], env["PROMPT_FIELDS"])
        prompt_fields["afc_cwd"] = self._afc_cwd
        prompt_fields["prompt_end"] = self._prompt

    def _prompt(self) -> str:
        """
        Generate the prompt suffix based on the last command's exit status.

        :return: Green '$' for success, red '$' for failure
        """
        history = XSH.history
        assert history is not None
        if len(history) == 0 or history[-1].rtn == 0:
            return "{BOLD_GREEN}${RESET}"
        return "{BOLD_RED}${RESET}"

    def _afc_cwd(self) -> str:
        """
        Get the current working directory for prompt display.

        :return: Current working directory path
        """
        return self.cwd

    def _relative_path(self, filename: str) -> str:
        """
        Convert a relative path to an absolute path based on cwd.

        :param filename: Relative or absolute path
        :return: Absolute path
        """
        return posixpath.join(self.cwd, filename)

    def _do_show_help(self):
        """Display a list of all available shell commands."""
        buf = ""
        for k, _v in self._commands.items():
            buf += f"👾 {k}\n"
        print(buf)

    def _do_pwd(self) -> None:
        """Print the current working directory."""
        print(self.cwd)

    def _do_link(self, target: str, source: str) -> None:
        """
        Create a symbolic link on the device.

        :param target: Target path that the link will point to
        :param source: Path where the link will be created
        """
        self.afc.link(self.relative_path(target), self.relative_path(source), AfcLinkType.SYMLINK)

    def _do_cd(self, directory: Annotated[str, Arg(completer=_dir_arg_completer)]) -> None:
        """
        Change the current working directory.

        :param directory: Directory path to change to (relative or absolute)
        """
        directory = self.relative_path(directory)
        directory = posixpath.normpath(directory)
        if self.afc.exists(directory):
            self.cwd = directory
            self._update_prompt()
            self._schedule_completion_cache_refresh(self.cwd)
        else:
            print(f"[ERROR] {directory} does not exist")

    def do_ls(self, args: list[str], stdin: Optional[TextIO], stdout: Optional[TextIO], stderr: Optional[TextIO]):
        """
        List directory contents with Unix ls-like formatting.

        Supports various ls options for formatting and filtering.
        """
        try:
            with ls_cli.make_context("ls", args) as ctx:
                files = list(map(self._relative_path, ctx.params.pop("files")))
                files = files if files else [self.cwd]
                Ls(AfcLsStub(self, stdout))(*files, **ctx.params)
        except _ls_cli_click.exceptions.Exit:
            pass

    def _do_walk(self, directory: Annotated[str, Arg(completer=_dir_arg_completer)]):
        """
        Recursively walk a directory tree and print all paths.

        :param directory: Root directory to walk
        """
        for root, dirs, files in cast(
            Iterator[tuple[str, list[str], list[str]]], self.afc.walk(self.relative_path(directory))
        ):
            for name in files:
                print(posixpath.join(root, name))
            for name in dirs:
                print(posixpath.join(root, name))

    def _do_cat(self, filename: Annotated[str, Arg(completer=_path_arg_completer)]):
        """
        Display the contents of a file.

        :param filename: Path to the file to display
        """
        print(try_decode(self.afc.get_file_contents(self.relative_path(filename))))

    def _do_rm(self, file: Annotated[list[str], Arg(nargs="+", completer=_path_arg_completer)]):
        """
        Remove one or more files or directories.

        :param file: List of file/directory paths to remove
        """
        for filename in file:
            self.afc.rm(self.relative_path(filename))

    def _do_pull(
        self,
        remote_path: Annotated[str, Arg(completer=_path_arg_completer)],
        local_path: str,
        ignore_errors: Annotated[bool, Arg("--ignore-errors", action="store_true")] = False,
        progress_bar: Annotated[bool, Arg("--progress-bar", action="store_true")] = False,
    ) -> None:
        """
        Pull a file or directory from device to local machine.

        Parameters
        ----------
        remote_path : str
            Path on the device to pull from
        local_path : str
            Local destination path
        ignore_errors : bool, optional
            Ignore errors and continue (--ignore-errors flag)
        progress_bar : bool, optional
            Show progress bar for large files (--progress_bar flag)
        """

        def log(src: str, dst: str):
            print(f"{src} --> {dst}")

        self.afc.pull(
            remote_path,
            local_path,
            callback=log,
            src_dir=self.cwd,
            ignore_errors=ignore_errors,
            progress_bar=progress_bar,
        )

    def _do_push(self, local_path: str, remote_path: Annotated[str, Arg(completer=_path_arg_completer)]):
        """
        Push a file or directory from local machine to device.

        :param local_path: Local source path
        :param remote_path: Destination path on the device
        """

        def log(src: str, dst: str):
            print(f"{src} --> {dst}")

        self.afc.push(local_path, self.relative_path(remote_path), callback=log)

    def _do_head(self, filename: Annotated[str, Arg(completer=_path_arg_completer)]):
        """
        Display the first 32 bytes of a file.

        :param filename: Path to the file
        """
        print(try_decode(self.afc.get_file_contents(self.relative_path(filename))[:32]))

    def _do_hexdump(self, filename: Annotated[str, Arg(completer=_path_arg_completer)]):
        """
        Display a hexadecimal dump of a file's contents.

        :param filename: Path to the file
        """
        print(cast(Any, hexdump).hexdump(self.afc.get_file_contents(self.relative_path(filename)), result="return"))

    def _do_mkdir(self, filename: Annotated[str, Arg(completer=_path_arg_completer)]):
        """
        Create a directory on the device.

        :param filename: Path of the directory to create
        """
        self.afc.makedirs(self.relative_path(filename))

    def _do_info(self):
        """Display device file system information."""
        for k, v in self.afc.get_device_info().items():
            print(f"{k}: {v}")

    def _do_mv(
        self,
        source: Annotated[str, Arg(completer=_path_arg_completer)],
        dest: Annotated[str, Arg(completer=_path_arg_completer)],
    ):
        """
        Move or rename a file or directory.

        :param source: Source path
        :param dest: Destination path
        """
        return self.afc.rename(self.relative_path(source), self.relative_path(dest))

    def _do_stat(self, filename: Annotated[str, Arg(completer=_path_arg_completer)]):
        """
        Display detailed file or directory statistics.

        :param filename: Path to the file or directory
        """
        for k, v in self.afc.stat(self.relative_path(filename)).items():
            print(f"{k}: {v}")

    def relative_path(self, filename: str) -> str:
        """
        Convert a relative path to an absolute path based on cwd.

        :param filename: Relative or absolute path
        :return: Absolute path
        """
        return posixpath.join(self.cwd, filename)

    def _update_prompt(self) -> None:
        """Update the shell prompt with syntax highlighting."""
        self.prompt = cast(
            str,
            highlight(
                f"[{self.afc.service_name}:{self.cwd}]$ ",
                cast(Any, lexers).BashSessionLexer(),
                cast(Any, formatters).Terminal256Formatter(style="solarized-dark"),
            ),
        ).strip()

    def _complete(self, text: str, line: str, begidx: int, endidx: int):
        """
        Provide path completion for commands (internal method).

        :param text: Current text being completed
        :param line: Full command line
        :param begidx: Beginning index of text
        :param endidx: Ending index of text
        :return: List of completion options
        """
        curdir_diff = posixpath.dirname(text)
        dirname = posixpath.join(self.cwd, curdir_diff)
        prefix = posixpath.basename(text)
        return [
            str(posixpath.join(curdir_diff, filename))
            for filename in self.afc.listdir(dirname)
            if filename.startswith(prefix)
        ]

    def _complete_first_arg(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """
        Complete only the first argument of a command.

        :return: Completion options for first arg, empty list otherwise
        """
        if self._count_completion_parts(line, begidx) > 1:
            return []
        return self._complete(text, line, begidx, endidx)

    def _complete_push_arg(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """
        Completion for push command (local path, then remote path).

        :return: Local completions for first arg, remote for second
        """
        count = self._count_completion_parts(line, begidx)
        if count == 1:
            return self._complete_local(text)
        elif count == 2:
            return self._complete(text, line, begidx, endidx)
        else:
            return []

    def _complete_pull_arg(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """
        Completion for pull command (remote path, then local path).

        :return: Remote completions for first arg, local for second
        """
        count = self._count_completion_parts(line, begidx)
        if count == 1:
            return self._complete(text, line, begidx, endidx)
        elif count == 2:
            return self._complete_local(text)
        else:
            return []

    @staticmethod
    def _complete_local(text: str):
        """
        Provide local file system path completions.

        :param text: Current text being completed
        :return: List of local path completions
        """
        path = pathlib.Path(text)
        path_iter = path.iterdir() if text.endswith(os.path.sep) else path.parent.iterdir()
        return [str(p) for p in path_iter if str(p).startswith(text)]

    @staticmethod
    def _count_completion_parts(line: str, begidx: int):
        """
        Count the number of space-separated parts in a command line.

        :param line: Command line text
        :param begidx: Index to count parts up to
        :return: Number of parts
        """
        # Strip the " for paths including spaces.
        return len(shlex.split(line[:begidx].rstrip('"')))


if __name__ == str(pathlib.Path(__file__).absolute()):
    """
    Entry point for xonsh RC script.

    This block is executed when the file is loaded as an xonsh RC script,
    initializing the AFC shell with the context provided by AfcShell.create().
    """
    rc = cast(AfcShell, _xsh_ctx()["_class"](_xsh_ctx()["_lockdown"], _xsh_ctx()["_service"]))
    # fix fzf conflicts
    _xsh_env = cast(Any, XSH).env
    assert _xsh_env is not None
    _xsh_env["fzf_history_binding"] = ""  # Ctrl+R
    _xsh_env["fzf_ssh_binding"] = ""  # Ctrl+S
    _xsh_env["fzf_file_binding"] = ""  # Ctrl+T
    _xsh_env["fzf_dir_binding"] = ""  # Ctrl+G
